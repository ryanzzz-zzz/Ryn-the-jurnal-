/* RYN THE JOURNAL - kalkulasi statistik. Semua angka dihitung dari data trade asli, dalam satuan R. */
(function (root) {
  const parseRR = (s) => {
    if (s == null || s === '') return 0;
    s = String(s).trim();
    if (s.includes(':')) { const [a, b] = s.split(':').map(Number); return a > 0 && b > 0 ? b / a : 0; }
    return parseFloat(s) > 0 ? parseFloat(s) : 0;
  };
  // R aktual: TP = RR target, SL = -1R, BE = 0R
  const rOf = (t) => (t.result === 'TP' ? parseRR(t.rr) : t.result === 'SL' ? -1 : 0);
  const hasFav = (t) => t.maxFav !== '' && t.maxFav != null && !isNaN(+t.maxFav);
  // Ideal R: pergerakan maksimum searah yang dicatat user (untuk TP minimal sama dengan R aktual)
  const idealOf = (t) => (!hasFav(t) ? null : t.result === 'TP' ? Math.max(+t.maxFav, rOf(t)) : +t.maxFav);
  const sortT = (ts) => [...ts].sort((a, b) => String(a.date).localeCompare(String(b.date)) || (a.no || 0) - (b.no || 0));

  function calc(ts) {
    const s = sortT(ts);
    let w = 0, l = 0, b = 0, gw = 0, gl = 0, tot = 0, mw = 0, ml = 0, cw = 0, cl = 0, best = null, worst = null;
    const eq = [0];
    for (const t of s) {
      const r = rOf(t); tot += r; eq.push(tot);
      if (t.result === 'TP') { w++; gw += r; cw++; cl = 0; }
      else if (t.result === 'SL') { l++; gl += -r; cl++; cw = 0; }
      else { b++; cw = 0; cl = 0; }
      mw = Math.max(mw, cw); ml = Math.max(ml, cl);
      if (!best || r > rOf(best)) best = t;
      if (!worst || r < rOf(worst)) worst = t;
    }
    const n = s.length, wr = n ? w / n : 0, lr = n ? l / n : 0;
    const avgWin = w ? gw / w : 0, avgLoss = l ? gl / l : 0;
    const rrs = s.map((t) => parseRR(t.rr)).filter((x) => x > 0);
    const ideals = s.map(idealOf).filter((x) => x != null);
    const sl = s.filter((t) => t.result === 'SL' && hasFav(t));
    return {
      n, w, l, b, wr, lr, tot, avg: n ? tot / n : 0, avgWin, avgLoss,
      exp: wr * avgWin - lr * avgLoss, gw, gl, pf: gl > 0 ? gw / gl : null,
      mw, ml, eq, best, worst, sorted: s,
      avgRR: rrs.length ? rrs.reduce((a, c) => a + c, 0) / rrs.length : null,
      maxRR: rrs.length ? Math.max(...rrs) : null,
      idealAvg: ideals.length ? ideals.reduce((a, c) => a + c, 0) / ideals.length : null,
      idealMax: ideals.length ? Math.max(...ideals) : null,
      idealN: ideals.length,
      couldProfit: sl.filter((t) => +t.maxFav >= 1).length,   // SL, tapi harga sempat >= +1R
      couldBE: sl.filter((t) => +t.maxFav > 0 && +t.maxFav < 1).length // SL, sempat searah <1R (BE bisa menyelamatkan)
    };
  }

  // keyFn mengembalikan array key (trade multi-select masuk ke setiap bucket)
  function groupBy(ts, keyFn) {
    const m = new Map();
    for (const t of ts) for (const k of new Set(keyFn(t))) { if (!m.has(k)) m.set(k, []); m.get(k).push(t); }
    return [...m.entries()].map(([k, v]) => ({ key: k, s: calc(v) }));
  }

  const has = (arr, sel) => !sel.length || (arr || []).some((x) => sel.includes(x));
  function applyFilter(ts, f) {
    return ts.filter((t) =>
      (!f.from || t.date >= f.from) && (!f.to || t.date <= f.to) &&
      has(t.pairs, f.pair) && has(t.sessions, f.session) && has([t.direction], f.dir) &&
      has(t.models, f.model) && has(t.tfs, f.tf) && has(t.days, f.day) && has([t.result], f.result));
  }

  const api = { parseRR, rOf, idealOf, hasFav, calc, groupBy, applyFilter, sortT };
  if (typeof module !== 'undefined') module.exports = api; else root.Stats = api;
})(typeof window !== 'undefined' ? window : globalThis);
