/* RYN THE JOURNAL - app utama. Data: IndexedDB (trades + images). Tanpa server. */
const S = window.Stats;
const OPT = {
  day: ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY'],
  pair: ['XAUUSD', 'NAS100', 'US30', 'EURUSD', 'GBPUSD'],
  session: ['ASIA SESSION', 'LONDON SESSION', 'NEW YORK AM', 'NEW YORK PM'],
  model: ['FVG', 'IFVG', 'LIQUIDITY SWEEP', 'MSS', 'ORDER BLOCK', 'REJECTION BLOCK', 'SELL SIDE LIQUIDITY', 'BUY SIDE LIQUIDITY', 'LIQUIDITY VOID', 'ASIA HIGH', 'ASIA LOW', 'LONDON HIGH', 'LONDON LOW', 'SMT', 'SSMT', 'CISD', 'SUPPORT', 'RESISTANCE', 'SBR', 'RBS', 'BREAKER BLOCK', 'BREAK', 'SWEEP', 'OHLC', 'OLHC', 'CRT'],
  tf: ['H4', 'H1', 'M15', 'M5', 'M3', 'M1'],
  rr: ['1:1', '1:1.5', '1:2', '1:3'],
  risk: ['0.25%', '0.5%', '1%', '2%'],
  dir: ['BUY', 'SELL'], result: ['TP', 'SL', 'BE']
};
const SHORT = { 'ORDER BLOCK': 'OB', 'LIQUIDITY SWEEP': 'LS', 'REJECTION BLOCK': 'RB', 'BREAKER BLOCK': 'BB', 'SELL SIDE LIQUIDITY': 'SSL', 'BUY SIDE LIQUIDITY': 'BSL', 'LIQUIDITY VOID': 'LV' };
const MON = ['JAN', 'FEB', 'MAR', 'APR', 'MEI', 'JUN', 'JUL', 'AGU', 'SEP', 'OKT', 'NOV', 'DES'];
const emptyF = () => ({ from: '', to: '', pair: [], session: [], dir: [], model: [], tf: [], day: [], result: [] });

const st = { tab: 'dash', sub: 'period', trades: [], filter: emptyF(), showF: false, search: '', set: loadSet() };
function loadSet() {
  const d = { currency: 'USD', risk: '0.5%', rr: '1:2', min: 5, theme: 'dark' };
  try { return Object.assign(d, JSON.parse(localStorage.getItem('ryn.set') || '{}')); } catch (e) { return d; }
}
const saveSet = () => localStorage.setItem('ryn.set', JSON.stringify(st.set));

/* ---------- IndexedDB ---------- */
const DB = (() => {
  let db;
  const open = () => new Promise((res, rej) => {
    const r = indexedDB.open('ryn-journal', 1);
    r.onupgradeneeded = () => { r.result.createObjectStore('trades', { keyPath: 'id' }); r.result.createObjectStore('images', { keyPath: 'id' }); };
    r.onsuccess = () => { db = r.result; res(); }; r.onerror = () => rej(r.error);
  });
  const tx = (s, m, fn) => new Promise((res, rej) => {
    const t = db.transaction(s, m); const rq = fn(t.objectStore(s));
    t.oncomplete = () => res(rq && rq.result); t.onerror = () => rej(t.error);
  });
  return { open, all: (s) => tx(s, 'readonly', (o) => o.getAll()), get: (s, k) => tx(s, 'readonly', (o) => o.get(k)),
    put: (s, v) => tx(s, 'readwrite', (o) => o.put(v)), del: (s, k) => tx(s, 'readwrite', (o) => o.delete(k)), clear: (s) => tx(s, 'readwrite', (o) => o.clear()) };
})();
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
async function reload() { st.trades = await DB.all('trades'); render(); }

/* ---------- util ---------- */
const $ = (s) => document.querySelector(s);
const esc = (x) => String(x == null ? '' : x).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const fr = (x) => (x == null ? '--' : (x > 0 ? '+' : '') + (+x).toFixed(2) + 'R');
const pc = (x) => (x * 100).toFixed(1) + '%';
const num = (x, d = 2) => (x == null ? '--' : (+x).toFixed(d));
const cls = (x) => (x > 0 ? 'up' : x < 0 ? 'dn' : '');
const fdate = (d) => { const p = String(d).split('-'); return p.length === 3 ? `${+p[2]} ${MON[+p[1] - 1]} ${p[0]}` : d; };
const dayOf = (d) => ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'][new Date(d + 'T12:00:00').getDay()];
const sh = (m) => SHORT[m] || m;
const chips = (k, list, sel, act) => `<div class="chips">${list.map((v) => `<button class="chip${sel.includes(v) ? ' on' : ''}" data-act="${act}" data-k="${k}" data-v="${esc(v)}">${esc(v)}</button>`).join('')}</div>`;
const view = () => S.applyFilter(st.trades, st.filter);

/* ---------- render ---------- */
function render() {
  document.documentElement.dataset.theme = st.set.theme;
  document.querySelectorAll('nav button').forEach((b) => b.classList.toggle('on', b.dataset.tab === st.tab));
  const v = $('#view');
  v.innerHTML = { dash: rDash, journal: rJournal, analytics: rAnalytics, settings: rSettings }[st.tab]();
}
const filterActive = () => Object.entries(st.filter).some(([, x]) => (Array.isArray(x) ? x.length : x));
function filterPanel() {
  const f = st.filter;
  const grp = (t, k, l) => `<label class="f">${t}</label>${chips(k, l, f[k], 'fchip')}`;
  return `<details ${st.showF ? 'open' : ''} data-act="ftoggle"><summary>FILTER ${filterActive() ? '(AKTIF)' : ''}</summary>
  <div class="row"><div><label class="f">FROM</label><input type="date" data-act="fdate" data-k="from" value="${f.from}"></div><div><label class="f">TO</label><input type="date" data-act="fdate" data-k="to" value="${f.to}"></div></div>
  ${grp('PAIR', 'pair', [...new Set([...OPT.pair, ...st.trades.flatMap((t) => t.pairs)])])}${grp('SESSION', 'session', OPT.session)}${grp('DIRECTION', 'dir', OPT.dir)}
  ${grp('MODEL', 'model', OPT.model)}${grp('TIME FRAME', 'tf', OPT.tf)}${grp('DAY', 'day', OPT.day)}${grp('RESULT', 'result', OPT.result)}
  <div style="padding:12px 0"><button class="btn ghost sm" data-act="freset">RESET FILTER</button></div></details>`;
}
const stat = (l, v, s = '', c = '') => `<div class="card stat"><div class="l">${l}</div><div class="v ${c}">${v}</div><div class="s">${s}&nbsp;</div></div>`;
const noData = () => '<div class="empty">NO TRADING DATA YET</div>';

function rDash() {
  const ts = view(), c = S.calc(ts);
  let h = `<div class="top"><h1>DASHBOARD</h1><button class="btn" data-act="add">+ ADD TRADE</button></div>` + filterPanel();
  if (!ts.length) return h + noData();
  const bt = (t) => (t ? `#${String(t.no).padStart(3, '0')} ${t.pairs[0] || ''} ${fr(S.rOf(t))}` : '--');
  h += `<div class="grid">
  ${stat('TOTAL TRADES', c.n)}${stat('TOTAL R', fr(c.tot), '', cls(c.tot))}
  ${stat('WIN', c.w, '', 'up')}${stat('LOSS', c.l, '', 'dn')}
  ${stat('BE', c.b, '', 'be')}${stat('AVERAGE R', fr(c.avg), '', cls(c.avg))}
  ${stat('WIN RATE', pc(c.wr))}${stat('LOSS RATE', pc(c.lr))}
  ${stat('EXPECTANCY', fr(c.exp), 'per trade', cls(c.exp))}${stat('PROFIT FACTOR', c.pf == null ? 'N/A' : num(c.pf))}
  ${stat('AVERAGE RR', c.avgRR == null ? '--' : '1:' + num(c.avgRR), 'RR target trade')}${stat('MAX RR', c.maxRR == null ? '--' : '1:' + num(c.maxRR))}
  ${stat('IDEAL AVG RR', c.idealAvg == null ? '--' : '1:' + num(c.idealAvg), c.idealN + ' trade berdata')}${stat('MAX IDEAL RR', c.idealMax == null ? '--' : '1:' + num(c.idealMax))}
  ${stat('COULD HAVE PROFIT', c.couldProfit, 'SL, sempat ≥ +1R')}${stat('COULD HAVE BE', c.couldBE, 'SL, sempat searah <1R')}
  ${stat('MAX CONSEC. WIN', c.mw)}${stat('MAX CONSEC. LOSS', c.ml)}
  ${stat('BEST TRADE', bt(c.best), '', 'up')}${stat('WORST TRADE', bt(c.worst), '', 'dn')}</div>`;
  return h + `<h2>EQUITY CURVE (CUMULATIVE R)</h2><div class="card">${lineChart(c.eq, ['START', ...c.sorted.map((t) => t.date)])}</div>`;
}

function tradeCard(t) {
  const r = S.rOf(t);
  return `<div class="card trade" data-act="open" data-id="${t.id}">
  <div class="hd"><span>#${String(t.no).padStart(3, '0')}</span><span>${fdate(t.date)}</span></div>
  <div class="big">${esc(t.pairs.join(' + '))} • ${t.direction}</div>
  <div class="mut">${esc(t.sessions.join(', '))}</div>
  <div>${esc(t.models.map(sh).join(' • '))}</div><div class="mut">${esc(t.tfs.join(' • '))}</div>
  <div class="row" style="margin-top:6px"><span>RR ${esc(t.rr)} &nbsp; RISK ${esc(t.risk)}</span><span class="rs ${cls(r)}" style="text-align:right">${t.result} ${fr(r)}</span></div></div>`;
}
function rJournal() {
  const q = st.search.trim().toLowerCase();
  let ts = view();
  if (q) ts = ts.filter((t) => JSON.stringify(t).toLowerCase().includes(q));
  ts = S.sortT(ts).reverse();
  return `<div class="top"><h1>JOURNAL</h1><button class="btn" data-act="add">+ ADD TRADE</button></div>
  <div style="margin:10px 0"><input type="text" placeholder="SEARCH (pair, model, note...)" data-act="search" value="${esc(st.search)}"></div>${filterPanel()}
  ${ts.length ? ts.map(tradeCard).join('') : st.trades.length ? '<div class="empty">TIDAK ADA TRADE COCOK</div>' : noData()}`;
}

/* ---------- charts (SVG) ---------- */
function lineChart(vals, labels) {
  const W = 320, H = 160, p = 26, mn = Math.min(...vals, 0), mx = Math.max(...vals, 0), rg = mx - mn || 1;
  const X = (i) => p + (vals.length > 1 ? (i * (W - 2 * p)) / (vals.length - 1) : 0), Y = (v) => H - p - ((v - mn) / rg) * (H - 2 * p);
  const d = vals.map((v, i) => (i ? 'L' : 'M') + X(i).toFixed(1) + ' ' + Y(v).toFixed(1)).join(' ');
  const last = vals[vals.length - 1];
  return `<svg viewBox="0 0 ${W} ${H}" width="100%"><line x1="${p}" x2="${W - 4}" y1="${Y(0)}" y2="${Y(0)}" stroke="var(--line)"/>
  <path d="${d}" fill="none" stroke="${last >= 0 ? 'var(--up)' : 'var(--dn)'}" stroke-width="1.8"/>
  <text x="2" y="${Y(mx) + 3}">${num(mx, 1)}</text><text x="2" y="${Y(mn) + 3}">${num(mn, 1)}</text>
  <text x="${p}" y="${H - 6}">${fdate(labels[1] || '')}</text><text x="${W - 4}" y="${H - 6}" text-anchor="end">${fdate(labels[labels.length - 1])}</text></svg>`;
}
function barChart(items) {
  const w = Math.max(320, items.length * 46), H = 150, p = 22, mx = Math.max(...items.map((i) => Math.abs(i.v)), 1), mid = H / 2 - 4, bw = 26;
  return `<div style="overflow-x:auto"><svg viewBox="0 0 ${w} ${H}" width="${w}" height="${H}"><line x1="0" x2="${w}" y1="${mid}" y2="${mid}" stroke="var(--line)"/>` +
    items.map((it, i) => { const x = 10 + i * 46, hh = (Math.abs(it.v) / mx) * (mid - p + 10); const y = it.v >= 0 ? mid - hh : mid;
      return `<rect x="${x}" y="${y}" width="${bw}" height="${Math.max(hh, 1)}" fill="${it.v >= 0 ? 'var(--up)' : 'var(--dn)'}"/><text x="${x + bw / 2}" y="${it.v >= 0 ? y - 3 : y + hh + 10}" text-anchor="middle">${num(it.v, 1)}</text><text x="${x + bw / 2}" y="${H - 4}" text-anchor="middle">${it.l}</text>`; }).join('') + '</svg></div>';
}

/* ---------- analytics ---------- */
const TABS = [['period', 'PERIOD'], ['session', 'SESSION'], ['model', 'MODEL'], ['combo', 'COMBO'], ['pattern', 'PATTERN']];
function table(rows, first) {
  return `<div class="card tbl"><table><tr><th>${first}</th><th>TRD</th><th>W</th><th>L</th><th>BE</th><th>WR</th><th>TOT R</th><th>AVG R</th><th>EXP</th><th>PF</th></tr>` +
    rows.map((g) => { const s = g.s; return `<tr><td>${esc(g.key)}</td><td>${s.n}</td><td>${s.w}</td><td>${s.l}</td><td>${s.b}</td><td>${pc(s.wr)}</td><td class="${cls(s.tot)}">${fr(s.tot)}</td><td>${fr(s.avg)}</td><td class="${cls(s.exp)}">${fr(s.exp)}</td><td>${s.pf == null ? 'N/A' : num(s.pf)}</td></tr>`; }).join('') + '</table></div>';
}
const minS = () => +st.set.min;
const comboKey = (t) => `${t.pairs.join('+')} | ${t.sessions.join('+')} | ${t.direction} | ${[...t.models].sort().join('+')}`;
function combos(ts) {
  const m = new Map();
  const add = (k, t) => { if (!m.has(k)) m.set(k, []); m.get(k).push(t); };
  for (const t of ts) {
    add(comboKey(t), t);
    const md = [...t.models].sort().slice(0, 8);
    for (let i = 0; i < md.length; i++) for (let j = i + 1; j < md.length; j++) {
      add(md[i] + ' + ' + md[j], t);
      for (let k = j + 1; k < md.length; k++) add(md[i] + ' + ' + md[j] + ' + ' + md[k], t);
    }
  }
  return [...m.entries()].map(([k, v]) => ({ key: k, s: S.calc(v) })).filter((g) => g.s.n >= minS());
}
function rAnalytics() {
  const ts = view();
  let h = `<div class="top"><h1>ANALYTICS</h1></div><div class="tabs">${TABS.map(([k, l]) => `<button class="chip${st.sub === k ? ' on' : ''}" data-act="sub" data-v="${k}">${l}</button>`).join('')}</div>` + filterPanel();
  if (!ts.length) return h + noData();
  const c = S.calc(ts);
  if (st.sub === 'period') {
    const mo = S.groupBy(ts, (t) => [t.date.slice(0, 7)]).sort((a, b) => a.key.localeCompare(b.key));
    const yr = S.groupBy(ts, (t) => [t.date.slice(0, 4)]).sort((a, b) => a.key.localeCompare(b.key));
    h += `<h2>EQUITY CURVE</h2><div class="card">${lineChart(c.eq, ['START', ...c.sorted.map((t) => t.date)])}</div>
    <h2>PERFORMANCE BY MONTH</h2><div class="card">${barChart(mo.map((g) => ({ l: MON[+g.key.slice(5) - 1] + ' ' + g.key.slice(2, 4), v: g.s.tot })))}</div>
    <h2>PERFORMANCE BY YEAR</h2>${table(yr, 'YEAR')}`;
  } else if (st.sub === 'session') {
    const g = S.groupBy(ts, (t) => t.sessions); h += '<h2>PERFORMANCE BY SESSION</h2>' + table(OPT.session.map((k) => g.find((x) => x.key === k) || { key: k, s: S.calc([]) }), 'SESSION');
  } else if (st.sub === 'model') {
    const g = S.groupBy(ts, (t) => t.models).sort((a, b) => b.s.tot - a.s.tot), ok = g.filter((x) => x.s.n >= minS());
    h += `<h2>PERFORMANCE BY MODEL</h2>${table(g, 'MODEL')}<h2>RANKING (MIN ${minS()} TRADES)</h2><div class="card">` +
      (ok.length ? `<div class="ins">BEST PERFORMING MODEL<br><b class="up">${esc(ok[0].key)}</b> ${fr(ok[0].s.tot)} • WR ${pc(ok[0].s.wr)}</div><div class="ins" style="border:0">WORST PERFORMING MODEL<br><b class="dn">${esc(ok[ok.length - 1].key)}</b> ${fr(ok[ok.length - 1].s.tot)} • WR ${pc(ok[ok.length - 1].s.wr)}</div>` : '<span class="mut">Belum ada model dengan sampel cukup.</span>') + '</div>';
  } else if (st.sub === 'combo') {
    const all = combos(ts).sort((a, b) => b.s.exp - a.s.exp || b.s.tot - a.s.tot);
    const top = all.filter((g) => g.s.exp > 0).slice(0, 8), worst = [...all].reverse().filter((g) => g.s.exp <= 0 && !top.includes(g)).slice(0, 8);
    h += `<h2>MIN SAMPLE</h2>${chips('min', ['3', '5', '10', '20', '30'], [String(st.set.min)], 'setmin')}
    ${all.length ? '' : `<div class="empty" style="padding:24px">BELUM ADA KOMBINASI DENGAN ≥ ${minS()} TRADE</div>`}
    <h2>TOP PERFORMING COMBINATIONS</h2>${top.length ? table(top, 'COMBINATION') : '<div class="mut">--</div>'}<h2>WORST PERFORMING COMBINATIONS</h2>${worst.length ? table(worst, 'COMBINATION') : '<div class="mut">--</div>'}`;
  } else {
    h += `<h2>PATTERN (MIN ${minS()} TRADES PER POLA)</h2><div class="card">` + patterns(ts).map((x) => `<div class="ins">${x}</div>`).join('') + '</div>';
  }
  return h;
}
function patterns(ts) {
  const dims = [['SESSION', (t) => t.sessions], ['PAIR', (t) => t.pairs], ['DIRECTION', (t) => [t.direction]], ['DAY', (t) => t.days], ['MODEL', (t) => t.models], ['TIME FRAME', (t) => t.tfs],
    ['MONTH', (t) => [t.date.slice(0, 7)]], ['TIME ENTRY', (t) => { const m = /(\d{1,2}):/.exec(t.timeEntry || ''); return m ? [m[1].padStart(2, '0') + ':00'] : []; }], ['COMBINATION', (t) => [comboKey(t)]]];
  const out = [];
  for (const [name, fn] of dims) {
    const g = S.groupBy(ts, fn).filter((x) => x.s.n >= minS());
    if (g.length < 2) continue;
    const byWr = [...g].sort((a, b) => b.s.wr - a.s.wr), byR = [...g].sort((a, b) => b.s.tot - a.s.tot);
    out.push(`Data menunjukkan ${name} <b>${esc(byWr[0].key)}</b> memiliki win rate tertinggi (${pc(byWr[0].s.wr)} dari ${byWr[0].s.n} trade).`);
    if (byWr[byWr.length - 1].key !== byWr[0].key) out.push(`Data menunjukkan ${name} <b>${esc(byWr[byWr.length - 1].key)}</b> memiliki win rate terendah (${pc(byWr[byWr.length - 1].s.wr)} dari ${byWr[byWr.length - 1].s.n} trade).`);
    if (byR[0].key !== byWr[0].key) out.push(`Data menunjukkan ${name} <b>${esc(byR[0].key)}</b> menghasilkan total R terbesar (${fr(byR[0].s.tot)}).`);
    for (const x of g) if (x.s.l / x.s.n >= 0.7) out.push(`Data menunjukkan ${name} <b>${esc(x.key)}</b> mengalami ${x.s.l} loss dari ${x.s.n} trade.`);
  }
  if (!out.length) out.push(`Data menunjukkan sampel belum cukup. Butuh minimal ${minS()} trade per pola dan lebih dari satu pola untuk dibandingkan.`);
  return out;
}

/* ---------- settings ---------- */
function rSettings() {
  const s = st.set;
  return `<div class="top"><h1>SETTINGS</h1></div>
  <label class="f">CURRENCY</label><input type="text" data-act="set" data-k="currency" value="${esc(s.currency)}">
  <label class="f">DEFAULT RISK</label>${chips('risk', OPT.risk, [s.risk], 'setv')}
  <label class="f">DEFAULT RR</label>${chips('rr', OPT.rr, [s.rr], 'setv')}
  <label class="f">MINIMUM SAMPLE SIZE</label>${chips('min', ['3', '5', '10', '20', '30'], [String(s.min)], 'setmin')}
  <label class="f">DARK MODE</label>${chips('theme', ['dark', 'light'], [s.theme], 'setv')}
  <label class="f">DATA (${st.trades.length} TRADE)</label>
  <div class="grid"><button class="btn ghost" data-act="expcsv">EXPORT CSV</button><button class="btn ghost" data-act="impcsv">IMPORT CSV</button>
  <button class="btn ghost" data-act="backup">BACKUP</button><button class="btn ghost" data-act="restore">RESTORE</button></div>
  <p class="mut">CSV hanya berisi data trade. BACKUP (.json) berisi trade + semua screenshot. Data hilang bila aplikasi di-uninstall, simpan backup secara berkala.</p>
  <div style="margin-top:18px"><button class="btn danger sm" data-act="wipe">HAPUS SEMUA DATA</button></div>
  <input type="file" id="fcsv" accept=".csv,text/csv,text/plain" hidden><input type="file" id="fjson" accept=".json,application/json" hidden>`;
}

/* ---------- form add / edit ---------- */
let draft = null;
function newDraft(t) {
  if (t) return { ...JSON.parse(JSON.stringify(t)), rrC: '', riskC: '', pairC: '', newImgs: [], delImgs: [] };
  const d = new Date(), iso = new Date(d - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 10);
  return { id: null, date: iso, days: [dayOf(iso)].filter((x) => OPT.day.includes(x)), pairs: [], sessions: [], direction: '', models: [], tfs: [], rr: st.set.rr, rrC: '', risk: st.set.risk, riskC: '', pairC: '',
    result: '', timeEntry: '', maxFav: '', note: '', images: [], newImgs: [], delImgs: [] };
}
const tog = (arr, v) => { const i = arr.indexOf(v); i < 0 ? arr.push(v) : arr.splice(i, 1); };
function openForm(t) {
  draft = newDraft(t);
  const m = document.createElement('div'); m.className = 'modal'; m.id = 'form'; document.body.appendChild(m); drawForm();
}
function drawForm() {
  const d = draft, g = (k, l, sel, a = 'dm') => chips(k, l, sel, a);
  $('#form').innerHTML = `<div class="mh"><h1 style="font-size:14px">${d.id ? 'EDIT TRADE' : 'ADD TRADE'}</h1><button class="btn ghost sm" data-act="closef">CLOSE</button></div><div class="mb">
  <label class="f">DATE</label><input type="date" data-act="dfield" data-k="date" value="${d.date}">
  <label class="f">DAY</label>${g('days', OPT.day, d.days)}
  <label class="f">PAIR</label>${g('pairs', [...OPT.pair, ...d.pairs.filter((p) => !OPT.pair.includes(p))], d.pairs)}<input type="text" style="margin-top:6px" placeholder="CUSTOM PAIR (mis. USDJPY)" data-act="dfield" data-k="pairC" value="${esc(d.pairC)}">
  <label class="f">SESSION</label>${g('sessions', OPT.session, d.sessions)}
  <label class="f">DIRECTION</label>${g('direction', OPT.dir, [d.direction], 'ds')}
  <label class="f">MODEL / ENTRY MODEL</label>${g('models', OPT.model, d.models)}
  <label class="f">TIME FRAME</label>${g('tfs', OPT.tf, d.tfs)}
  <label class="f">RR</label>${g('rr', OPT.rr, [d.rr], 'ds')}<input type="text" style="margin-top:6px" placeholder="CUSTOM RR (mis. 1:2.5)" data-act="dfield" data-k="rrC" value="${esc(d.rrC)}">
  <label class="f">RISK / TRADE</label>${g('risk', OPT.risk, [d.risk], 'ds')}<input type="text" style="margin-top:6px" placeholder="CUSTOM RISK (mis. 0.75%)" data-act="dfield" data-k="riskC" value="${esc(d.riskC)}">
  <label class="f">RESULT</label>${g('result', OPT.result, [d.result], 'ds')}
  <label class="f">MAX FAVORABLE R / IDEAL R (opsional)</label><input type="number" step="0.01" inputmode="decimal" placeholder="mis. 1.5 = harga sempat +1.5R" data-act="dfield" data-k="maxFav" value="${esc(d.maxFav)}">
  <label class="f">TIME ENTRY</label><input type="text" placeholder="10:10 - 10:25" data-act="dfield" data-k="timeEntry" value="${esc(d.timeEntry)}">
  <label class="f">IMAGE</label><div class="imgs" id="thumbs"></div><button class="btn ghost sm" data-act="pickimg" style="margin-top:6px">+ TAMBAH SCREENSHOT</button><input type="file" id="fimg" accept="image/*" multiple hidden>
  <label class="f">NOTE</label><textarea data-act="dfield" data-k="note">${esc(d.note)}</textarea></div>
  <div class="mf"><button class="btn ghost" data-act="closef">BATAL</button><button class="btn" data-act="savet">SIMPAN</button></div>`;
  drawThumbs();
}
async function drawThumbs() {
  const box = $('#thumbs'); if (!box) return; box.innerHTML = '';
  const add = (id, url, kind) => { const w = document.createElement('div'); w.className = 'im'; w.innerHTML = `<img src="${url}" data-act="zoom"><button class="x" data-act="delimg" data-kind="${kind}" data-id="${id}">×</button>`; box.appendChild(w); };
  for (const id of draft.images) { const r = await DB.get('images', id); if (r) add(id, URL.createObjectURL(r.blob), 'old'); }
  for (const n of draft.newImgs) add(n.id, URL.createObjectURL(n.blob), 'new');
}
async function saveTrade() {
  const d = draft; d.rr = d.rrC.trim() || d.rr; d.risk = d.riskC.trim() || d.risk;
  const pc0 = d.pairC.trim().toUpperCase(); if (pc0 && !d.pairs.includes(pc0)) d.pairs.push(pc0);
  if (!d.date || !d.direction || !d.result || !S.parseRR(d.rr)) return alert('Lengkapi DATE, DIRECTION, RR (format 1:2), dan RESULT.');
  if (!d.pairs.length) return alert('Pilih atau isi minimal satu PAIR.');
  for (const n of d.newImgs) { await DB.put('images', { id: n.id, blob: n.blob }); d.images.push(n.id); }
  for (const id of d.delImgs) await DB.del('images', id);
  const no = d.no || Math.max(0, ...st.trades.map((t) => t.no || 0)) + 1;
  const t = { id: d.id || uid(), no, date: d.date, days: d.days, pairs: d.pairs, sessions: d.sessions, direction: d.direction, models: d.models, tfs: d.tfs, rr: d.rr, risk: d.risk,
    result: d.result, timeEntry: d.timeEntry, maxFav: d.maxFav === '' ? '' : +d.maxFav, note: d.note, images: d.images };
  await DB.put('trades', t); closeForm(); await reload();
}
const closeForm = () => { const f = $('#form'); if (f) f.remove(); draft = null; };

/* ---------- detail ---------- */
async function openDetail(id) {
  const t = st.trades.find((x) => x.id === id); if (!t) return;
  const r = S.rOf(t), m = document.createElement('div'); m.className = 'modal'; m.id = 'detail';
  const row = (l, v) => `<div class="ins"><span class="mut">${l}</span><br>${esc(v || '--')}</div>`;
  m.innerHTML = `<div class="mh"><h1 style="font-size:14px">#${String(t.no).padStart(3, '0')} ${esc(t.pairs.join(' + '))}</h1><button class="btn ghost sm" data-act="closed">CLOSE</button></div><div class="mb">
  <div class="rs ${cls(r)}" style="font-size:24px;font-weight:700">${t.result} ${fr(r)}</div>
  ${row('DATE', fdate(t.date) + ' • ' + t.days.join(', '))}${row('DIRECTION', t.direction)}${row('SESSION', t.sessions.join(', '))}${row('MODEL', t.models.join(' + '))}${row('TIME FRAME', t.tfs.join(' • '))}
  ${row('RR / RISK', t.rr + ' / ' + t.risk)}${row('MAX FAVORABLE R', S.hasFav(t) ? fr(t.maxFav) : '')}${row('TIME ENTRY', t.timeEntry)}${row('NOTE', t.note)}
  <div class="imgs" id="dimgs" style="margin-top:10px"></div></div>
  <div class="mf"><button class="btn danger" data-act="delt" data-id="${t.id}">DELETE</button><button class="btn" data-act="editt" data-id="${t.id}">EDIT</button></div>`;
  document.body.appendChild(m);
  for (const iid of t.images || []) { const r0 = await DB.get('images', iid); if (r0) { const im = document.createElement('img'); im.src = URL.createObjectURL(r0.blob); im.dataset.act = 'zoom'; $('#dimgs').appendChild(im); } }
}
function zoom(src) {
  const z = document.createElement('div'); z.className = 'modal'; z.style.cssText = 'background:#000;align-items:center;justify-content:center;z-index:40'; z.innerHTML = `<img src="${src}" style="max-width:100%;max-height:100%" data-act="closez">`; z.dataset.act = 'closez'; document.body.appendChild(z);
}

/* ---------- CSV / backup ---------- */
const CSVH = ['no', 'date', 'day', 'pair', 'session', 'direction', 'model', 'timeframe', 'rr', 'risk', 'result', 'time_entry', 'max_favorable_r', 'note'];
const q = (x) => '"' + String(x == null ? '' : x).replace(/"/g, '""') + '"';
function toCSV() {
  return [CSVH.join(','), ...S.sortT(st.trades).map((t) => [t.no, t.date, t.days.join('|'), t.pairs.join('|'), t.sessions.join('|'), t.direction, t.models.join('|'), t.tfs.join('|'), t.rr, t.risk, t.result, t.timeEntry, t.maxFav, t.note].map(q).join(','))].join('\n');
}
function parseCSV(txt) {
  const rows = []; let row = [], cur = '', inq = false;
  txt = txt.replace(/^\uFEFF/, '');
  for (let i = 0; i < txt.length; i++) {
    const ch = txt[i];
    if (inq) { if (ch === '"') { if (txt[i + 1] === '"') { cur += '"'; i++; } else inq = false; } else cur += ch; }
    else if (ch === '"') inq = true; else if (ch === ',') { row.push(cur); cur = ''; }
    else if (ch === '\n' || ch === '\r') { if (ch === '\r' && txt[i + 1] === '\n') i++; row.push(cur); cur = ''; if (row.some((x) => x !== '')) rows.push(row); row = []; }
    else cur += ch;
  }
  if (cur !== '' || row.length) { row.push(cur); rows.push(row); }
  return rows;
}
async function importCSV(txt) {
  const rows = parseCSV(txt); if (rows.length < 2) return alert('CSV kosong atau format salah.');
  const h = rows[0].map((x) => x.trim().toLowerCase()), ix = (k) => h.indexOf(k); let no = Math.max(0, ...st.trades.map((t) => t.no || 0)), ok = 0;
  const L = (v) => String(v || '').split('|').map((x) => x.trim()).filter(Boolean);
  for (const r of rows.slice(1)) {
    const g = (k) => (ix(k) < 0 ? '' : (r[ix(k)] || '').trim());
    const res = g('result').toUpperCase(), dir = g('direction').toUpperCase();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(g('date')) || !['TP', 'SL', 'BE'].includes(res) || !['BUY', 'SELL'].includes(dir)) continue;
    await DB.put('trades', { id: uid(), no: ++no, date: g('date'), days: L(g('day')), pairs: L(g('pair')), sessions: L(g('session')), direction: dir, models: L(g('model')), tfs: L(g('timeframe')),
      rr: g('rr') || '1:2', risk: g('risk'), result: res, timeEntry: g('time_entry'), maxFav: g('max_favorable_r') === '' ? '' : +g('max_favorable_r'), note: g('note'), images: [] }); ok++;
  }
  await reload(); alert(`${ok} trade diimpor dari ${rows.length - 1} baris.`);
}
const b2d = (b) => new Promise((res) => { const f = new FileReader(); f.onload = () => res(f.result); f.readAsDataURL(b); });
async function backup() {
  const imgs = []; for (const i of await DB.all('images')) imgs.push({ id: i.id, data: await b2d(i.blob) });
  await saveFile(`ryn-backup-${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify({ app: 'RYN THE JOURNAL', v: 1, trades: st.trades, images: imgs, settings: st.set }), 'application/json');
}
async function restore(txt) {
  let o; try { o = JSON.parse(txt); } catch (e) { return alert('File backup tidak valid.'); }
  if (!o || o.app !== 'RYN THE JOURNAL' || !Array.isArray(o.trades)) return alert('Bukan file backup RYN THE JOURNAL.');
  if (!confirm(`Restore akan MENGGANTI semua data saat ini dengan ${o.trades.length} trade dari backup. Lanjut?`)) return;
  await DB.clear('trades'); await DB.clear('images');
  for (const i of o.images || []) await DB.put('images', { id: i.id, blob: await (await fetch(i.data)).blob() });
  for (const t of o.trades) await DB.put('trades', t);
  if (o.settings) { st.set = Object.assign(st.set, o.settings); saveSet(); }
  await reload(); alert('Restore selesai.');
}
async function saveFile(name, text, mime) {
  const C = window.Capacitor;
  try {
    if (C && C.isNativePlatform && C.isNativePlatform()) {
      const { Filesystem, Share } = C.Plugins;
      const r = await Filesystem.writeFile({ path: name, data: text, directory: 'CACHE', encoding: 'utf8' });
      await Share.share({ title: name, url: r.uri, dialogTitle: 'Simpan / kirim file' });
    } else {
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: mime })); a.download = name; a.click();
    }
  } catch (e) { alert('Gagal menyimpan file: ' + (e.message || e)); }
}
const readFile = (f) => new Promise((res) => { const r = new FileReader(); r.onload = () => res(r.result); r.readAsText(f); });

/* ---------- events ---------- */
document.addEventListener('click', async (e) => {
  const el = e.target.closest('[data-act]'); if (!el) return;
  const a = el.dataset.act, k = el.dataset.k, v = el.dataset.v, f = st.filter;
  if (a === 'ftoggle') return;
  if (a === 'fchip') { tog(f[k], v); st.showF = true; return render(); }
  if (a === 'freset') { st.filter = emptyF(); st.showF = true; return render(); }
  if (a === 'sub') { st.sub = v; return render(); }
  if (a === 'add') return openForm();
  if (a === 'open') return openDetail(el.dataset.id);
  if (a === 'closed') return $('#detail').remove();
  if (a === 'closef') return closeForm();
  if (a === 'closez') return el.closest('.modal').remove();
  if (a === 'zoom') return zoom(el.src);
  if (a === 'editt') { $('#detail').remove(); return openForm(st.trades.find((x) => x.id === el.dataset.id)); }
  if (a === 'delt') {
    if (!confirm('Hapus trade ini beserta screenshot-nya?')) return;
    const t = st.trades.find((x) => x.id === el.dataset.id); for (const i of t.images || []) await DB.del('images', i);
    await DB.del('trades', t.id); $('#detail').remove(); return reload();
  }
  if (a === 'dm') { tog(draft[k], v); el.classList.toggle('on'); return; }
  if (a === 'ds') { draft[k] = v; if (k === 'rr') draft.rrC = ''; if (k === 'risk') draft.riskC = ''; el.parentNode.querySelectorAll('.chip').forEach((c) => c.classList.toggle('on', c === el)); return; }
  if (a === 'pickimg') return $('#fimg').click();
  if (a === 'delimg') { const id = el.dataset.id; if (el.dataset.kind === 'old') { draft.images = draft.images.filter((x) => x !== id); draft.delImgs.push(id); } else draft.newImgs = draft.newImgs.filter((x) => x.id !== id); return drawThumbs(); }
  if (a === 'savet') return saveTrade();
  if (a === 'setv') { st.set[k] = v; saveSet(); return render(); }
  if (a === 'setmin') { st.set.min = +v; saveSet(); return render(); }
  if (a === 'expcsv') return st.trades.length ? saveFile('ryn-journal.csv', toCSV(), 'text/csv') : alert('NO TRADING DATA YET');
  if (a === 'impcsv') return $('#fcsv').click();
  if (a === 'backup') return backup();
  if (a === 'restore') return $('#fjson').click();
  if (a === 'wipe') { if (confirm('Hapus SEMUA trade dan screenshot? Tidak bisa dibatalkan.') && confirm('Yakin? Pastikan sudah BACKUP.')) { await DB.clear('trades'); await DB.clear('images'); reload(); } }
});
document.addEventListener('change', async (e) => {
  const el = e.target;
  if (el.id === 'fimg') { for (const f of el.files) draft.newImgs.push({ id: uid(), blob: f }); el.value = ''; return drawThumbs(); }
  if (el.id === 'fcsv' && el.files[0]) { const t = await readFile(el.files[0]); el.value = ''; return importCSV(t); }
  if (el.id === 'fjson' && el.files[0]) { const t = await readFile(el.files[0]); el.value = ''; return restore(t); }
  const a = el.dataset.act;
  if (a === 'fdate') { st.filter[el.dataset.k] = el.value; st.showF = true; render(); }
  if (a === 'dfield' && el.dataset.k === 'date') { draft.date = el.value; const dn = dayOf(el.value); if (OPT.day.includes(dn)) { draft.days = [dn]; drawForm(); } }
  if (a === 'set') { st.set[el.dataset.k] = el.value; saveSet(); }
});
document.addEventListener('input', (e) => {
  const el = e.target, a = el.dataset.act;
  if (a === 'dfield' && el.dataset.k !== 'date') draft[el.dataset.k] = el.value;
  if (a === 'search') { st.search = el.value; const p = el.selectionStart; render(); const n = $('[data-act=search]'); n.focus(); n.setSelectionRange(p, p); }
});
document.addEventListener('toggle', (e) => { if (e.target.dataset && e.target.dataset.act === 'ftoggle') st.showF = e.target.open; }, true);
document.querySelectorAll('nav button').forEach((b) => b.addEventListener('click', () => { st.tab = b.dataset.tab; render(); $('#view').scrollTop = 0; }));

(async () => {
  try { navigator.storage && navigator.storage.persist && navigator.storage.persist(); } catch (e) {}
  await DB.open(); await reload();
  setTimeout(() => { const s = $('#splash'); if (s) s.remove(); }, 2200);
})();
