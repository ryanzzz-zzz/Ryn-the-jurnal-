# RYN THE JOURNAL
Trading journal Android, offline, tanpa server. Web app (HTML/CSS/JS) dibungkus Capacitor jadi APK.
Data: IndexedDB (trades + screenshot sebagai Blob).

## Struktur
- www/index.html, style.css, app.js (UI + DB + analytics), stats.js (semua rumus)
- test/stats.test.js  -> `npm test` (test case 3 trade dari spesifikasi)
- capacitor.config.json, package.json

## Build APK (butuh Node 18+, JDK 17, Android Studio/SDK)
    npm install
    npm test
    npx cap add android
    npx cap sync android
    cd android && ./gradlew assembleDebug        # Windows: gradlew.bat assembleDebug
APK: android/app/build/outputs/apk/debug/app-debug.apk
Atau: `npx cap open android` lalu Build > Build APK(s) di Android Studio.

## Ganti nama
Sebelum `cap add android`: ubah `appName` di capacitor.config.json.
Sesudahnya: android/app/src/main/res/values/strings.xml (app_name, title_activity_main).
## Ganti icon
Android Studio: klik kanan res > New > Image Asset. Atau `npm i -D @capacitor/assets`,
taruh assets/icon-only.png (1024x1024) lalu `npx capacitor-assets generate --android`.
## Font
Default memakai monospace sistem. Untuk JetBrains Mono: taruh .woff2 di www/fonts/ dan tambah @font-face di style.css.
