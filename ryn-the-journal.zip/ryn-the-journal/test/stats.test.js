const S = require('../www/stats.js'); const assert = require('assert');
const t = [{ date: '2026-09-01', no: 1, result: 'TP', rr: '1:2' }, { date: '2026-09-02', no: 2, result: 'SL', rr: '1:2', maxFav: 1.5 }, { date: '2026-09-03', no: 3, result: 'TP', rr: '1:2' }];
const c = S.calc(t);
assert.strictEqual(c.n, 3); assert.strictEqual(c.w, 2); assert.strictEqual(c.l, 1); assert.strictEqual(c.b, 0);
assert.ok(Math.abs(c.wr - 2 / 3) < 1e-9); assert.strictEqual(c.tot, 3); assert.strictEqual(c.avg, 1);
assert.ok(Math.abs(c.exp - 1) < 1e-9); assert.strictEqual(c.pf, 4); assert.strictEqual(c.mw, 1); assert.strictEqual(c.ml, 1);
assert.deepStrictEqual(c.eq, [0, 2, 1, 3]); assert.strictEqual(c.couldProfit, 1);
assert.strictEqual(S.calc([{ date: 'x', no: 1, result: 'TP', rr: '1:2' }]).pf, null);
console.log('OK: semua test kalkulasi lolos');
